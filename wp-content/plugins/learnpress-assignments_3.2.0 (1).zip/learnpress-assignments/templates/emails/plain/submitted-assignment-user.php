== {{email_heading}} ==

Dear {{user_name}},

You just submitted assignment "{{assignment_name}}" {{course_url}} ({{course_name}}).

Click {{course_url}} ({{course_name}}) to see more. Thanks you.

{{footer_text}}