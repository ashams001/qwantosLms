== {{email_heading}} ==

Dear {{user_name}},

You just evaluated assignment "{{assignment_name}}" in "{{course_name}}" {{course_url}}.

{{footer_text}}