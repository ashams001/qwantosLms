== {{email_heading}} ==

Dear {{user_name}},

Your assignment "{{assignment_name}}" in "{{course_name}}" {{course_url}} has been evaluated.

{{footer_text}}