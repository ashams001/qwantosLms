=== LearnPress - Content Drip ===
Contributors: thimpress, tunnhn, leehld
Donate link:
Tags: drip, lms, commission, fee, learnpress, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Requires at least: 3.8
Tested up to: 5.2.2
Stable tag: 3.1.3
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==

== Installation ==

1. Download Coming soon courses Plugin to your desktop.
2. If downloaded as a zip archive, extract the Plugin folder to your desktop.
3. With your FTP program, upload the Plugin folder to the wp-content/plugins folder in your WordPress directory online.
4. Go to Plugins screen and find the newly uploaded Plugin in the list.
5. Click Activate to activate it.

== Changelog ==
= 3.1.4 =
~ Fixed bug when using prerequisite type with Internal Time.

= 3.1.3 =
~ Fixed several notice messages when viewing on front end.
+ Added 1 more hook to check the status of the assignment item.

= 3.1.2 =
~ Fixed js error: not load select2.js.

= 3.1.1 =
~ Fixed bug: store January 1st 1970 when saving settings.

= 3.1.0 =
~ Allowed Instructors accessing Content Drip Settings page.
~ Fixed bug: several texts can not be translated.
~ Fixed bug: store wrong date when using unusally date format.

= 3.0.9 =
~ Fixed bug: error loadding when guest user view lesson

= 3.0.8 =
~ Fixed bug: Missing column "Prerequisite" in list of "Drip items"

= 3.0.7 =
~ Fixed bug: no lesson, quiz show in Content Drip Settings page for Course

= 3.0.6 =
+ Specific date to open for each item
+ Prerequisite items
+ Improve config drip items

= 3.0.5 =
+ Compatible with Learnpress 3.0.8

= 3.0.4 =
+ Update restrict content immediately items

= 3.0.3 =
+ Fix Cannot click on options in Drip items table

= 3.0.2 =
+ Update filter template content

= 3.0.1 =
+ Fix issue add content drip meta box in admin course page
+ Update feature Open course items sequentially

= 3.0.0 =
+ Updated to be compatible with Learnpress 3.0.0