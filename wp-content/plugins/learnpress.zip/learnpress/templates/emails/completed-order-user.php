{{header}}

<p>Hi <strong>{{order_user_name}}</strong>,</p>

<p>Your recent order at {{site_title}} has been completed.<p>

<p>See your order details below:</p>

{{order_items_table}}

{{footer}}
