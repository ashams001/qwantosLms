{{header}}

<p>Dear <strong>{{course_user_name}}</strong>,

<p>Unfortunately! The course you created <a href="{{course_edit_url}}">{{course_name}}</a> isn't ready for sale now.</p>

<p>Please <a href="{{login_url}}">login</a> and update your course to meet our minimum requirements for quality and/or our policies.</p>

{{footer}}