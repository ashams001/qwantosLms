{{header}}

<p>User {{request_email}} has requested to become an Instructor at {{site_title}}</p>

<p>Phone: {{request_phone}}</p>

<p>Message: {{request_message}}</p>

<p>Please login to {{site_title}} and access {{admin_user_manager}} to manage the requesting.</p>

<p>Accept the requesting: {{accept_url}}</p>

<p>Deny the requesting: {{deny_url}}</p>

{{footer}}