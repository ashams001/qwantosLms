{{header}}

<p>Order placed by <strong>{{order_user_name}}</strong> has been completed</p>

{{order_items_table}}

{{footer}}