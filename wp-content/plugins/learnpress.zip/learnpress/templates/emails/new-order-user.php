{{header}}

<p>Hi <strong>{{order_user_name}}</strong></p>

<p>We have received your order at <strong>{{site_title}}</strong> and send you the details.<p>

<p>You can also login to your account to see more details.<p>

{{order_items_table}}

{{footer}}
