{{header}}

<p>Hi <strong>Guest</strong>,</p>

<p>
    Thank you for purchasing course with {{site_title}}!
    We have received your order and it is now being processed.
    We will send you an email once your order has been processed.
<p>

<p>See your order details below:</p>

<p>Order key: {{order_key}}</p>

{{order_items_table}}

{{footer}}
