{{header}}

<p><a href="{{course_url}}">{{course_name}}</a> has just updated.</p>

<p>Please <a href="{{login_url}}">login</a> and start learning now.</p>

{{footer}}