{{header}}

{{order_items_table}}

Your order has just changed status to <strong>{{order_status}}</strong>

<p>View order: <a href="{{order_detail_url}}">{{order_number}}</a></p>

{{footer}}