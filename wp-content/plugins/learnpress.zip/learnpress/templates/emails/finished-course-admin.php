{{header}}

<p>User {{user_display_name}} ({{user_email}}) has finished course  <a target="_blank" href="{{course_url}}">"{{course_name}}"</a></p>

<p>User has <strong>{{course_grade}}</strong> course with {{course_result_percent}} of total</p>

{{footer}}