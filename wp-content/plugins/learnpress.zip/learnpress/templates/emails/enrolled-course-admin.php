{{header}}

<p>User {{user_display_name}} ({{user_email}}) has enrolled course  <a target="_blank" href="{{course_url}}">"{{course_name}}"</a></p>

{{footer}}