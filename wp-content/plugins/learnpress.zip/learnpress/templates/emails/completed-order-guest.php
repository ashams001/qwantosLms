{{header}}

<p>Hi <strong>Guest</strong>,</p>

<p>Your recent order at {{site_title}} has been completed.<p>

<p>See your order details below:</p>

<p>Order key: {{order_key}}</p>

{{order_items_table}}

{{footer}}
