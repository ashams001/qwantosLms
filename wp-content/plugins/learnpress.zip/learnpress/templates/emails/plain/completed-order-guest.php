
== {{header}} ==

** Hi "Guest", **

** Your recent order at "{{site_title}}" has been completed. **

** See your order details below: **

** Order key: {{order_key}} **

{{order_items_table}}

== {{footer}} ==
