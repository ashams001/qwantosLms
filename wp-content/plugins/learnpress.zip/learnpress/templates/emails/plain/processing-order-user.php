
== {{header}} ==

** Hi "{{order_user_name}}" **

** We have received your order at "{{site_title}}" and send you the details. **

** Your order is now processing. **

** You can also login to your account to see more details. **

{{order_items_table}}

== {{footer}} ==
