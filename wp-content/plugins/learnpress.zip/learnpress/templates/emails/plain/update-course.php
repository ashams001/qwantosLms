
== {{email_heading}} ==

"{{course_url}}" ({{course_name}}) has just been updated.

Please login {{login_url}} and start learning now.

{{footer_text}}