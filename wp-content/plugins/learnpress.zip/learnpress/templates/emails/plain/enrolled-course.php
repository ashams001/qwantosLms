
== {{email_heading}} ==

You have enrolled in the course  "{{course_name}}" {{course_url}}.

Please login {{login_url}} and start learning now.

{{footer_text}}