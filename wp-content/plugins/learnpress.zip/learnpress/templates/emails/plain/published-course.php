
== {{email_heading}} ==

Dear {{course_user_name}},

Congratulation! The course you created here {{course_edit_url}} ({{course_name}}) is available now.

Click {{course_url}} to view your course.

{{footer_text}}