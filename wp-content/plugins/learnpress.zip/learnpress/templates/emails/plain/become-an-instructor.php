== {{header}} ==

** User {{request_email}} has requested to become an Instructor at {{site_title}} **

** Phone:   {{request_phone}} **

** Message: {{request_message}} **

** Please login to {{site_title}} and access {{admin_user_manager}} to to manage the requesting. **

** Accept the requesting: {{accept_url}} **

** Deny the requesting: {{deny_url}} **

== {{footer}} ==