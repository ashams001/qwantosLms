
== {{email_heading}} ==

Dear {{user_name}}
	
You have finished the course "{{course_name}}" {{course_url}}.

Please go to your profile {{user_profile_url}} and view your course results.
	
{{footer_text}}