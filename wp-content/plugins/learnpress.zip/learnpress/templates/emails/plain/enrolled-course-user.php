
== {{header}} ==

** Congrats! You have enrolled course "{{course_name}}" {{course_url}} **

== {{footer}} ==