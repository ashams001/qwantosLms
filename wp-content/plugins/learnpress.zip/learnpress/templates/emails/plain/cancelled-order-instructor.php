
== {{header}} ==

** Order placed by "{{order_user_name}}" has been cancelled **

{{order_items_table}}

== {{footer}} ==