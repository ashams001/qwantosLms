
== {{email_heading}} ==

{{order_items_table}}

Your order has just changed status to <strong>{{order_status}}</strong>

View order: {{order_detail_url}}

{{footer_text}}
