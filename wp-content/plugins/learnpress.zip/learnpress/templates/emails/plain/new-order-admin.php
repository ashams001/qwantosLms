
== {{header}} ==

** New order placed by "{{order_user_name}}" **

{{order_items_table}}

== {{footer}} ==