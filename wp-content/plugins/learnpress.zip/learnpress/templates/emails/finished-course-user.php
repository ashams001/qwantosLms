{{header}}

<p>Congrats! You have finished course <a target="_blank" href="{{course_url}}">"{{course_name}}"</a></p>

<p>You achieved {{course_result_percent}} of course and your grade is <strong>{{course_grade}}</strong></p>

{{footer}}