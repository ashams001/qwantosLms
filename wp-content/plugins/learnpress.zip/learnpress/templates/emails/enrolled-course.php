{{header}}

<p>You have enrolled in the course <a target="_blank" href="{{course_url}}">{{course_name}}</a></p>

<p>Please <a href="{{login_url}}">login</a> and start learning now.</p>

{{footer}}