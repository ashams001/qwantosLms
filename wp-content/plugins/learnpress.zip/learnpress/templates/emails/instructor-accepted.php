{{header}}

<p>Congrats! You become an Instructor at <strong>{{site_title}}</strong></p>

<p>Please <a href="{{login_url}}">login</a> to <strong>{{site_title}}</strong> and start teaching</p>

{{footer}}