<?php
/**
 * This template for hide the comment
 */