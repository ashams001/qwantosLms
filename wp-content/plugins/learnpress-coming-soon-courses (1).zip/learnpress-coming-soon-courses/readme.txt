=== LearnPress - Coming Soon Courses ===
Contributors: thimpress, phonglq, tunnhn
Donate link:
Tags: coming soon, schedule, lms, commission, fee, learnpress, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Requires at least: 3.8
Tested up to: 4.9.4
Stable tag: 3.0.1
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==

== Installation ==

1. Download Coming soon courses Plugin to your desktop.
2. If downloaded as a zip archive, extract the Plugin folder to your desktop.
3. With your FTP program, upload the Plugin folder to the wp-content/plugins folder in your WordPress directory online.
4. Go to Plugins screen and find the newly uploaded Plugin in the list.
5. Click Activate to activate it.

== Changelog ==

= 3.0.2 =
+ Fixed: not display time text although the option is enabled.

= 3.0.1 =
+ Fixed: not display the comming soon message on Archive page.

= 3.0.0 =
+ Updated to be compatible with Learnpress 3.0.0

= 2.2.1 =
+ Fixed: countdown wrong