<?php
/*
function e_list_courses_assignments_link() {
	?>
    <a href=""><?php esc_html_e( 'Assignments', 'learnpress-frontend-editor' ); ?></a>
	<?php
}
add_action( 'fe/after-list-courses-meta', 'e_list_courses_assignments_link' );
*/