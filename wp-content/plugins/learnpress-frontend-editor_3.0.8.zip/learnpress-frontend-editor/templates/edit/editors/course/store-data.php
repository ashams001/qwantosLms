<?php
global $post;

$data = array(
	'course_ID' => $post->ID
);