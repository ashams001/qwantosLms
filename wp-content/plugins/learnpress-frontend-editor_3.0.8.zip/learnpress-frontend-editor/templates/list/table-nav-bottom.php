<?php
/**
 * Displays pagination of list courses at the bottom
 *
 * @author  ThimPress
 * @apckage Frontend_Editor/Templates
 * @version 3.0.0
 */

defined( 'ABSPATH' ) or die;

?>
<div id="e-post-list-pagination">
	<?php e_list_post_nav(); ?>
</div>
