=== LearnPress - Randome question quiz ===

== Changelog ==
= 3.1.1 =
~ Fixed bug: not start the quiz with the first question after randomizing.

= 3.1 =
~ Compatyible with frontend editor addon


= 3.0.0 =
+ Initial released.
