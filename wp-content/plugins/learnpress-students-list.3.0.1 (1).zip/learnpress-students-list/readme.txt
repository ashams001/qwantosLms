=== LearnPress - Students List ===
Contributors: thimpress, tunnhn, leehld
Donate link:
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Requires at least: 4.5
Tested up to: 4.9.7
Stable tag: 3.0.1
License: Split License
License URI: https://help.market.envato.com/hc/en-us/articles/202501064-What-is-Split-Licensing-and-the-GPL-

== Description ==

Student list add-on for LearnPress.

== Changelog ==

= 3.0.1 =
+ Update text domain

= 3.0.0 =
+ Compatible with Learnpress 3.0.0
