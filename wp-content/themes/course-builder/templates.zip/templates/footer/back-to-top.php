<?php
/**
 * Back To Top
 */
?>

<i class="fa fa-angle-up" aria-hidden="true"></i>