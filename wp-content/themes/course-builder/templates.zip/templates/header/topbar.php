<div id="thim-header-topbar">
	<div class="container">
		<?php dynamic_sidebar( 'topbar' ); ?>
	</div>
</div><!-- #thim-header-topbar -->
